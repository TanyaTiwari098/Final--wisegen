# Crypto Arbitrage Bot

A fully automated cryptocurrency spot arbitrage trading bot that operates across multiple exchanges (Binance, Kraken, Bitget, and Coinbase) with a focus on ETH/USD trading pairs.

## Features

- **Multi-Exchange Support**: Integrated with Binance, Kraken, Bitget, and Coinbase APIs
- **Real-time Arbitrage Detection**: Continuously scans for profitable arbitrage opportunities
- **Risk Management**: Built-in risk management protocols with configurable parameters
- **User-Friendly Dashboard**: Web-based dashboard for monitoring and configuration
- **Profit Tracking**: Real-time profit history charts and trade analytics
- **Low Latency**: Optimized for high-frequency trading opportunities
- **Configurable Parameters**: Adjustable profit thresholds, risk limits, and trading amounts


```env
# Binance API (https://www.binance.com/en/my/settings/api-management)
BINANCE_API_KEY=your_binance_api_key
BINANCE_SECRET_KEY=your_binance_secret_key

# Kraken API (https://www.kraken.com/u/security/api)
KRAKEN_API_KEY=your_kraken_api_key
KRAKEN_SECRET_KEY=your_kraken_secret_key

# Bitget API (https://www.bitget.com/en/spot/apidoc)
BITGET_API_KEY=your_bitget_api_key
BITGET_SECRET_KEY=your_bitget_secret_key
BITGET_PASSPHRASE=your_bitget_passphrase

# Coinbase API (https://www.coinbase.com/settings/api)
COINBASE_API_KEY=your_coinbase_api_key
COINBASE_SECRET_KEY=your_coinbase_secret_key
```



### 1. Running the Bot

1. Click the "Run" button 
2. Open the web interface 
3. Configure your trading parameters in the dashboard
4. Click "Start Bot" to begin automated trading

## Dashboard Features

### Bot Status
- Real-time bot status (Running/Stopped)
- Uptime tracking
- Total trades executed
- Total profit/loss

### Configuration Panel
- Trading pair selection
- Minimum profit percentage threshold
- Maximum trade amount
- Risk percentage settings
- Exchange enable/disable toggles

### Live Data
- Real-time price feeds from all exchanges
- Account balances across all exchanges
- Current arbitrage opportunities
- Trade execution history

### Analytics
- Profit history chart
- Performance metrics
- Risk management statistics

## Risk Management

The bot includes several risk management features:

- **Daily Loss Limits**: Configurable maximum daily loss threshold
- **Position Sizing**: Risk-based position sizing algorithms
- **Maximum Concurrent Trades**: Limits simultaneous open positions
- **Price Volatility Checks**: Filters out potentially stale or erroneous price data
- **Exchange Reliability Scoring**: Monitors exchange performance and reliability

## Configuration Options

### Trading Parameters
- `min_profit_percentage`: Minimum profit threshold (default: 0.5%)
- `max_trade_amount`: Maximum trade size in USD (default: $100)
- `risk_percentage`: Risk per trade as percentage of account (default: 2%)

### Risk Management
- `daily_loss_limit`: Maximum daily loss in USD (default: $500)
- `max_concurrent_trades`: Maximum simultaneous trades (default: 3)

### Exchange Settings
- Enable/disable individual exchanges
- Adjust exchange weight for trade distribution
- Configure API credentials per exchange

## API Endpoints

The bot exposes several REST API endpoints:

- `GET /api/bot_status` - Get current bot status
- `POST /api/start_bot` - Start the trading bot
- `POST /api/stop_bot` - Stop the trading bot
- `GET /api/balances` - Get account balances
- `GET /api/prices` - Get current market prices
- `GET /api/opportunities` - Get arbitrage opportunities
- `GET /api/trade_history` - Get trade history
- `GET /api/profit_history` - Get profit history for charts



### Common Issues

1. **API Connection Errors**: Check your API keys and network connectivity
2. **Insufficient Funds**: Ensure adequate balances on all exchanges
3. **Rate Limiting**: Reduce update frequency if hitting rate limits
4. **Stale Prices**: Check exchange connectivity and API status

### Logs

The bot provides comprehensive logging:
- Application logs in the console
- Trade execution logs
- Error logs with detailed stack traces

## Adding New Exchanges

To add a new exchange:

1. Add exchange configuration to `exchange_manager.py`
2. Update the dashboard HTML to include the new exchange
3. Add API credentials to environment variables
4. Test thoroughly in sandbox mode

## License

This project is for educational purposes only. Use at your own risk. Cryptocurrency trading involves substantial risk and is not suitable for all investors.
