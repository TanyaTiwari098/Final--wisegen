
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class RiskManager:
    def __init__(self, config):
        self.config = config
        self.trade_history = []
        self.daily_loss_limit = config.get('daily_loss_limit', 500)  # USD
        self.max_concurrent_trades = config.get('max_concurrent_trades', 3)
        self.min_profit_percentage = config.get('min_profit_percentage', 0.5)
        self.max_trade_amount = config.get('max_trade_amount', 100)
        self.current_trades = 0
        self.daily_pnl = 0.0
        self.last_reset = datetime.now().date()
    
    def should_execute_trade(self, opportunity):
        """Determine if a trade should be executed based on risk parameters"""
        try:
            # Reset daily PnL if it's a new day
            if datetime.now().date() != self.last_reset:
                self.daily_pnl = 0.0
                self.last_reset = datetime.now().date()
            
            # Check profit percentage threshold
            if opportunity['profit_percentage'] < self.min_profit_percentage:
                logger.info(f"Trade rejected: Profit percentage {opportunity['profit_percentage']}% below threshold")
                return False
            
            # Check daily loss limit
            if self.daily_pnl < -self.daily_loss_limit:
                logger.info(f"Trade rejected: Daily loss limit reached (${self.daily_pnl})")
                return False
            
            # Check maximum concurrent trades
            if self.current_trades >= self.max_concurrent_trades:
                logger.info(f"Trade rejected: Maximum concurrent trades reached ({self.current_trades})")
                return False
            
            # Check exchange reliability score
            if not self.is_exchange_reliable(opportunity['buy_exchange']) or \
               not self.is_exchange_reliable(opportunity['sell_exchange']):
                logger.info("Trade rejected: Exchange reliability check failed")
                return False
            
            # Check price volatility
            if self.is_price_too_volatile(opportunity):
                logger.info("Trade rejected: Price volatility too high")
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"Error in risk assessment: {str(e)}")
            return False
    
    def is_exchange_reliable(self, exchange_name):
        """Check if exchange is reliable based on recent performance"""
        # Simple reliability check - in production, this would be more sophisticated
        reliable_exchanges = ['binance', 'kraken', 'bitget', 'coinbase']
        return exchange_name in reliable_exchanges
    
    def is_price_too_volatile(self, opportunity):
        """Check if price difference indicates excessive volatility"""
        # If profit percentage is too high, it might indicate stale data or volatility
        if opportunity['profit_percentage'] > 10:  # 10% seems too good to be true
            return True
        return False
    
    def calculate_position_size(self, opportunity, available_balance):
        """Calculate optimal position size based on risk parameters"""
        try:
            # Risk-based position sizing
            risk_amount = available_balance * (self.config.get('risk_percentage', 2.0) / 100)
            
            # Position size based on profit percentage (higher profit = larger position)
            profit_multiplier = min(opportunity['profit_percentage'] / self.min_profit_percentage, 3.0)
            position_size = risk_amount * profit_multiplier
            
            # Cap at maximum trade amount
            position_size = min(position_size, self.max_trade_amount)
            
            return position_size
            
        except Exception as e:
            logger.error(f"Error calculating position size: {str(e)}")
            return 0
    
    def record_trade(self, trade_result):
        """Record trade result for risk tracking"""
        self.trade_history.append({
            'timestamp': datetime.now().isoformat(),
            'profit': trade_result.get('profit', 0),
            'success': trade_result.get('success', False)
        })
        
        # Update daily PnL
        self.daily_pnl += trade_result.get('profit', 0)
        
        # Clean old trade history (keep last 30 days)
        cutoff_date = datetime.now() - timedelta(days=30)
        self.trade_history = [
            trade for trade in self.trade_history
            if datetime.fromisoformat(trade['timestamp']) > cutoff_date
        ]
    
    def get_risk_metrics(self):
        """Get current risk metrics"""
        return {
            'daily_pnl': self.daily_pnl,
            'daily_loss_limit': self.daily_loss_limit,
            'current_trades': self.current_trades,
            'max_concurrent_trades': self.max_concurrent_trades,
            'trades_today': len([
                trade for trade in self.trade_history
                if datetime.fromisoformat(trade['timestamp']).date() == datetime.now().date()
            ])
        }
    
    def update_trade_count(self, delta):
        """Update current trade count"""
        self.current_trades = max(0, self.current_trades + delta)
