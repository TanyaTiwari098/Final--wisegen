
import ccxt
import logging
import os
from datetime import datetime

logger = logging.getLogger(__name__)

class ExchangeManager:
    def __init__(self, config):
        self.config = config
        self.exchanges = {}
        self.initialize_exchanges()
    
    def initialize_exchanges(self):
        """Initialize exchange connections"""
        exchange_configs = {
            'binance': {
                'class': ccxt.binance,
                'sandbox': False,
                'apiKey': os.environ.get('BINANCE_API_KEY'),
                'secret': os.environ.get('BINANCE_SECRET_KEY'),
                'enableRateLimit': True,
                'options': {'defaultType': 'spot'},
                'timeout': 30000,
                'rateLimit': 1200
            },
            'kraken': {
                'class': ccxt.kraken,
                'sandbox': False,
                'apiKey': os.environ.get('KRAKEN_API_KEY'),
                'secret': os.environ.get('KRAKEN_SECRET_KEY'),
                'enableRateLimit': True,
                'timeout': 30000,
                'rateLimit': 3000
            },
            'bitget': {
                'class': ccxt.bitget,
                'sandbox': False,
                'apiKey': os.environ.get('BITGET_API_KEY'),
                'secret': os.environ.get('BITGET_SECRET_KEY'),
                'password': os.environ.get('BITGET_PASSPHRASE'),
                'enableRateLimit': True,
                'timeout': 30000,
                'rateLimit': 1000
            },
            'coinbase': {
                'class': ccxt.coinbase,
                'sandbox': False,
                'apiKey': os.environ.get('COINBASE_API_KEY'),
                'secret': os.environ.get('COINBASE_SECRET_KEY'),
                'enableRateLimit': True,
                'timeout': 30000
            }
        }
        
        # Always try to initialize all exchanges, regardless of config
        for exchange_name, exchange_config in exchange_configs.items():
            try:
                # Check if API credentials are available
                api_key = exchange_config.get('apiKey')
                secret = exchange_config.get('secret')
                
                if api_key and secret:
                    exchange_class = exchange_config['class']
                    del exchange_config['class']
                    
                    exchange = exchange_class(exchange_config)
                    
                    # Test the connection
                    exchange.load_markets()
                    
                    # Verify API access
                    try:
                        balance = exchange.fetch_balance()
                        logger.info(f"Successfully initialized {exchange_name} with API access")
                    except Exception as api_error:
                        logger.warning(f"{exchange_name} API test failed: {str(api_error)}")
                    
                    self.exchanges[exchange_name] = exchange
                    logger.info(f"Initialized {exchange_name} exchange")
                    
                else:
                    logger.warning(f"Missing API credentials for {exchange_name}")
                    
            except Exception as e:
                logger.error(f"Failed to initialize {exchange_name}: {str(e)}")
                
        logger.info(f"Initialized {len(self.exchanges)} exchanges: {list(self.exchanges.keys())}")
    
    def get_all_prices(self):
        """Get current prices from all exchanges"""
        prices = {}
        
        # Get enabled exchanges from config
        enabled_exchanges = []
        if hasattr(self.config, 'get') and 'exchanges' in self.config:
            for exchange_name, config in self.config['exchanges'].items():
                if config.get('enabled', False):
                    enabled_exchanges.append(exchange_name)
        else:
            enabled_exchanges = ['binance', 'kraken', 'bitget']  # Default enabled
        
        for exchange_name in enabled_exchanges:
            try:
                if exchange_name in self.exchanges:
                    # Fetch real price from exchange
                    exchange = self.exchanges[exchange_name]
                    
                    # Different exchanges may have different symbols
                    symbol = 'ETH/USD'
                    if exchange_name == 'kraken':
                        symbol = 'ETH/USD'  # Kraken supports ETH/USD
                    elif exchange_name == 'binance':
                        symbol = 'ETH/USDT'  # Binance uses USDT
                    elif exchange_name == 'bitget':
                        symbol = 'ETH/USDT'  # Bitget uses USDT
                    
                    ticker = exchange.fetch_ticker(symbol)
                    logger.info(f"Fetched price from {exchange_name}: {ticker['last']}")
                    
                    prices[exchange_name] = {
                        'ETH/USD': ticker['last'],
                        'bid': ticker['bid'],
                        'ask': ticker['ask'],
                        'timestamp': datetime.now().isoformat()
                    }
                else:
                    logger.warning(f"Exchange {exchange_name} not initialized")
                    prices[exchange_name] = {
                        'ETH/USD': 0.0,
                        'bid': 0.0,
                        'ask': 0.0,
                        'timestamp': datetime.now().isoformat(),
                        'error': 'Exchange not initialized'
                    }
                    
            except Exception as e:
                logger.error(f"Error fetching price from {exchange_name}: {str(e)}")
                prices[exchange_name] = {
                    'ETH/USD': 0.0,
                    'bid': 0.0,
                    'ask': 0.0,
                    'timestamp': datetime.now().isoformat(),
                    'error': str(e)
                }
        
        return prices
    
    def get_balances(self):
        """Get balances from all exchanges"""
        balances = {}
        
        # Get enabled exchanges from config
        enabled_exchanges = []
        if hasattr(self.config, 'get') and 'exchanges' in self.config:
            for exchange_name, config in self.config['exchanges'].items():
                if config.get('enabled', False):
                    enabled_exchanges.append(exchange_name)
        else:
            enabled_exchanges = ['binance', 'kraken', 'bitget']  # Default enabled
        
        for exchange_name in enabled_exchanges:
            try:
                if exchange_name in self.exchanges:
                    # Fetch real balance from exchange
                    exchange = self.exchanges[exchange_name]
                    balance = exchange.fetch_balance()
                    logger.info(f"Fetched balance from {exchange_name}: {balance}")
                    
                    # Handle different exchange response formats
                    usd_balance = 0
                    eth_balance = 0
                    
                    if exchange_name == 'kraken':
                        # Kraken uses different currency codes, try multiple formats
                        for usd_key in ['ZUSD', 'USD', 'USDT']:
                            if usd_key in balance and balance[usd_key]:
                                usd_balance = balance[usd_key].get('free', 0)
                                usd_total = balance[usd_key].get('total', 0)
                                break
                        
                        for eth_key in ['XETH', 'ETH']:
                            if eth_key in balance and balance[eth_key]:
                                eth_balance = balance[eth_key].get('free', 0)
                                eth_total = balance[eth_key].get('total', 0)
                                break
                    elif exchange_name == 'bitget':
                        # Bitget format
                        usd_balance = balance.get('USDT', {}).get('free', 0) or balance.get('USD', {}).get('free', 0)
                        eth_balance = balance.get('ETH', {}).get('free', 0)
                        usd_total = balance.get('USDT', {}).get('total', 0) or balance.get('USD', {}).get('total', 0)
                        eth_total = balance.get('ETH', {}).get('total', 0)
                    else:
                        # Binance and others
                        usd_balance = balance.get('USDT', {}).get('free', 0) or balance.get('USD', {}).get('free', 0)
                        eth_balance = balance.get('ETH', {}).get('free', 0)
                        usd_total = balance.get('USDT', {}).get('total', 0) or balance.get('USD', {}).get('total', 0)
                        eth_total = balance.get('ETH', {}).get('total', 0)
                    
                    balances[exchange_name] = {
                        'USD': float(usd_balance) if usd_balance else 0.0,
                        'ETH': float(eth_balance) if eth_balance else 0.0,
                        'total_usd': float(usd_total) if usd_total else 0.0,
                        'total_eth': float(eth_total) if eth_total else 0.0
                    }
                    
                else:
                    logger.warning(f"Exchange {exchange_name} not initialized")
                    balances[exchange_name] = {
                        'USD': 0.0,
                        'ETH': 0.0,
                        'total_usd': 0.0,
                        'total_eth': 0.0
                    }
                    
            except Exception as e:
                logger.error(f"Error fetching balance from {exchange_name}: {str(e)}")
                balances[exchange_name] = {
                    'USD': 0.0,
                    'ETH': 0.0,
                    'total_usd': 0.0,
                    'total_eth': 0.0,
                    'error': str(e)
                }
        
        return balances
    
    def buy_order(self, exchange_name, symbol, amount, price):
        """Place a buy order"""
        try:
            if exchange_name in self.exchanges:
                exchange = self.exchanges[exchange_name]
                order = exchange.create_limit_buy_order(symbol, amount, price)
                logger.info(f"Buy order placed on {exchange_name}: {order}")
                return True
            return False
        except Exception as e:
            logger.error(f"Error placing buy order on {exchange_name}: {str(e)}")
            return False
    
    def sell_order(self, exchange_name, symbol, amount, price):
        """Place a sell order"""
        try:
            if exchange_name in self.exchanges:
                exchange = self.exchanges[exchange_name]
                order = exchange.create_limit_sell_order(symbol, amount, price)
                logger.info(f"Sell order placed on {exchange_name}: {order}")
                return True
            return False
        except Exception as e:
            logger.error(f"Error placing sell order on {exchange_name}: {str(e)}")
            return False
    
    def get_order_book(self, exchange_name, symbol):
        """Get order book for a symbol"""
        try:
            if exchange_name in self.exchanges:
                exchange = self.exchanges[exchange_name]
                return exchange.fetch_order_book(symbol)
            return None
        except Exception as e:
            logger.error(f"Error fetching order book from {exchange_name}: {str(e)}")
            return None
