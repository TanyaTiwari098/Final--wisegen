class Dashboard {
    constructor() {
        this.profitChart = null;
        this.updateInterval = null;
        this.initializeEventListeners();
        this.initializeProfitChart();
        this.loadConfiguration();
        this.startDataUpdates();
    }

    initializeEventListeners() {
        // Bot control buttons
        $('#startBot').on('click', () => this.startBot());
        $('#stopBot').on('click', () => this.stopBot());

        // Configuration save button
        $('#saveConfig').on('click', () => this.saveConfiguration());

        // Exchange toggles
        $('#binanceEnabled, #krakenEnabled, #bitgetEnabled, #coinbaseEnabled').on('change', () => this.updateExchangeConfig());
        $('#binanceWeight, #krakenWeight, #bitgetWeight, #coinbaseWeight').on('input', () => this.updateExchangeConfig());
    }

    initializeProfitChart() {
        const ctx = document.getElementById('profitChart').getContext('2d');
        this.profitChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Profit ($)',
                    data: [],
                    borderColor: '#00ff88',
                    backgroundColor: 'rgba(0, 255, 136, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: {
                            color: '#e0e0e0'
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: {
                            color: '#888'
                        },
                        grid: {
                            color: '#333'
                        }
                    },
                    y: {
                        ticks: {
                            color: '#888',
                            callback: function(value) {
                                return '$' + value.toFixed(2);
                            }
                        },
                        grid: {
                            color: '#333'
                        }
                    }
                }
            }
        });
    }

    async startBot() {
        try {
            const config = this.getConfiguration();
            const response = await fetch('/api/start_bot', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(config)
            });

            const result = await response.json();
            if (result.status === 'success') {
                this.showNotification('Bot started successfully', 'success');
                this.updateBotStatus('running');
            } else {
                this.showNotification(result.message, 'error');
            }
        } catch (error) {
            this.showNotification('Error starting bot: ' + error.message, 'error');
        }
    }

    async stopBot() {
        try {
            const response = await fetch('/api/stop_bot', {
                method: 'POST'
            });

            const result = await response.json();
            if (result.status === 'success') {
                this.showNotification('Bot stopped successfully', 'success');
                this.updateBotStatus('stopped');
            } else {
                this.showNotification(result.message, 'error');
            }
        } catch (error) {
            this.showNotification('Error stopping bot: ' + error.message, 'error');
        }
    }

    async loadConfiguration() {
        try {
            const response = await fetch('/api/config');
            const config = await response.json();

            $('#tradingPair').val(config.trading_pair || 'ETH/USD');
            $('#minProfit').val(config.min_profit_percentage || 0.5);
            $('#maxTradeAmount').val(config.max_trade_amount || 100);
            $('#riskPercentage').val(config.risk_percentage || 2.0);

            // Update exchange toggles
            const exchanges = config.exchanges || {};
            $('#binanceEnabled').prop('checked', exchanges.binance?.enabled || false);
            $('#krakenEnabled').prop('checked', exchanges.kraken?.enabled || false);
            $('#bitgetEnabled').prop('checked', exchanges.bitget?.enabled || false);
            $('#coinbaseEnabled').prop('checked', exchanges.coinbase?.enabled || false);

            $('#binanceWeight').val(exchanges.binance?.weight || 1.0);
            $('#krakenWeight').val(exchanges.kraken?.weight || 1.0);
            $('#bitgetWeight').val(exchanges.bitget?.weight || 1.0);
            $('#coinbaseWeight').val(exchanges.coinbase?.weight || 1.0);

        } catch (error) {
            console.error('Error loading configuration:', error);
        }
    }

    async saveConfiguration() {
        try {
            const config = this.getConfiguration();

            const response = await fetch('/api/config', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(config)
            });

            const result = await response.json();
            if (result.status === 'success') {
                this.showNotification('Configuration saved successfully', 'success');
            } else {
                this.showNotification('Error saving configuration', 'error');
            }
        } catch (error) {
            this.showNotification('Error saving configuration: ' + error.message, 'error');
        }
    }

    getConfiguration() {
        return {
            trading_pair: $('#tradingPair').val(),
            min_profit_percentage: parseFloat($('#minProfit').val()),
            max_trade_amount: parseFloat($('#maxTradeAmount').val()),
            risk_percentage: parseFloat($('#riskPercentage').val()),
            exchanges: {
                binance: {
                    enabled: $('#binanceEnabled').prop('checked'),
                    weight: parseFloat($('#binanceWeight').val())
                },
                kraken: {
                    enabled: $('#krakenEnabled').prop('checked'),
                    weight: parseFloat($('#krakenWeight').val())
                },
                bitget: {
                    enabled: $('#bitgetEnabled').prop('checked'),
                    weight: parseFloat($('#bitgetWeight').val())
                },
                coinbase: {
                    enabled: $('#coinbaseEnabled').prop('checked'),
                    weight: parseFloat($('#coinbaseWeight').val())
                }
            }
        };
    }

    updateExchangeConfig() {
        // Auto-save configuration when exchange settings change
        this.saveConfiguration();
    }

    startDataUpdates() {
        this.updateInterval = setInterval(() => {
            this.updateBotStatus();
            this.updatePrices();
            this.updateBalances();
            this.updateOpportunities();
            this.updateTradeHistory();
            this.updateProfitChart();
            this.updateTradingSummary();
            this.updateRecentTrades();
        }, 2000); // Update every 2 seconds
    }

    async updateBotStatus(status = null) {
        try {
            if (!status) {
                const response = await fetch('/api/bot_status');
                const data = await response.json();
                status = data.status;

                if (status === 'running') {
                    $('#currentStatus').text('Running');
                    $('#uptime').text(data.uptime);
                    $('#totalTrades').text(data.total_trades);
                    $('#totalProfit').text('$' + data.total_profit.toFixed(2));
                    $('#botStatus').text('Running').addClass('running');
                } else {
                    $('#currentStatus').text('Stopped');
                    $('#botStatus').text('Stopped').removeClass('running');
                }
            } else {
                $('#currentStatus').text(status === 'running' ? 'Running' : 'Stopped');
                $('#botStatus').text(status === 'running' ? 'Running' : 'Stopped');

                if (status === 'running') {
                    $('#botStatus').addClass('running');
                } else {
                    $('#botStatus').removeClass('running');
                }
            }
        } catch (error) {
            console.error('Error updating bot status:', error);
        }
    }

    async updatePrices() {
        try {
            const response = await fetch('/api/prices');
            const prices = await response.json();

            const container = $('#pricesContainer');
            container.empty();

            if (prices.error) {
                container.html('<div class="no-data">Error loading prices</div>');
                return;
            }

            Object.entries(prices).forEach(([exchange, data]) => {
                const price = data['ETH/USD'] || 0;
                const changePercent = (Math.random() - 0.5) * 2; // Random change for demo
                const changeClass = changePercent >= 0 ? 'positive' : 'negative';

                const priceHtml = `
                    <div class="price-item">
                        <div class="exchange-info">
                            <span class="exchange-name">${exchange.charAt(0).toUpperCase() + exchange.slice(1)}</span>
                            <span class="exchange-price">$${price.toFixed(2)}</span>
                        </div>
                        <div class="price-change ${changeClass}">${changePercent >= 0 ? '+' : ''}${changePercent.toFixed(2)}%</div>
                    </div>
                `;
                container.append(priceHtml);
            });
        } catch (error) {
            console.error('Error updating prices:', error);
            $('#pricesContainer').html('<div class="no-data">Error loading prices</div>');
        }
    }

    async updateBalances() {
        try {
            const response = await fetch('/api/balances');
            const balances = await response.json();

            const container = $('#balancesContainer');
            container.empty();

            if (balances.error) {
                container.html('<div class="no-data">Error loading balances</div>');
                return;
            }

            Object.entries(balances).forEach(([exchange, data]) => {
                const usdBalance = data.USD || 0;
                const ethBalance = data.ETH || 0;

                const balanceHtml = `
                    <div class="balance-item">
                        <div class="balance-row">
                            <span class="exchange-name">${exchange.charAt(0).toUpperCase() + exchange.slice(1)}</span>
                            <div class="balance-amounts">
                                <span class="balance-amount usd">$${usdBalance.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})} USD</span>
                                <span class="balance-amount eth">${ethBalance.toFixed(6)} ETH</span>
                            </div>
                        </div>
                    </div>
                `;
                container.append(balanceHtml);
            });
        } catch (error) {
            console.error('Error updating balances:', error);
            $('#balancesContainer').html('<div class="no-data">Error loading balances</div>');
        }
    }

    async updateOpportunities() {
        try {
            const response = await fetch('/api/opportunities');
            const opportunities = await response.json();

            const container = $('#opportunitiesContainer');
            container.empty();

            opportunities.forEach(opportunity => {
                const opportunityHtml = `
                    <div class="opportunity-item">
                        <div class="opportunity-info">
                            <span class="opportunity-pair">Buy: ${opportunity.buy_exchange} → Sell: ${opportunity.sell_exchange}</span>
                            <span class="opportunity-profit">+${opportunity.profit_percentage.toFixed(2)}%</span>
                        </div>
                        <div class="opportunity-details">
                            <span class="buy-price">Buy: $${opportunity.buy_price.toFixed(2)}</span>
                            <span class="sell-price">Sell: $${opportunity.sell_price.toFixed(2)}</span>
                        </div>
                    </div>
                `;
                container.append(opportunityHtml);
            });

            if (opportunities.length === 0) {
                container.html('<div class="no-opportunities">No arbitrage opportunities found</div>');
            }
        } catch (error) {
            console.error('Error updating opportunities:', error);
        }
    }

    async updateTradeHistory() {
        try {
            const response = await fetch('/api/trade_history');
            const trades = await response.json();

            const container = $('#tradeHistoryContainer');
            container.empty();

            trades.slice(-10).reverse().forEach(trade => {
                const time = new Date(trade.timestamp).toLocaleTimeString();
                const tradeHtml = `
                    <div class="trade-item">
                        <div class="trade-info">
                            <span class="trade-time">${time}</span>
                            <span class="trade-pair">ETH/USD</span>
                            <span class="trade-exchanges">${trade.buy_exchange} → ${trade.sell_exchange}</span>
                        </div>
                        <div class="trade-profit">+$${trade.profit.toFixed(2)}</div>
                    </div>
                `;
                container.append(tradeHtml);
            });

            if (trades.length === 0) {
                container.html('<div class="no-trades">No trades executed yet</div>');
            }
        } catch (error) {
            console.error('Error updating trade history:', error);
        }
    }

    async updateProfitChart() {
        try {
            const response = await fetch('/api/profit_history');
            const profitHistory = await response.json();

            const labels = profitHistory.map(point => {
                const date = new Date(point.timestamp);
                return date.toLocaleTimeString();
            });

            const data = profitHistory.map(point => point.total_profit);

            this.profitChart.data.labels = labels;
            this.profitChart.data.datasets[0].data = data;
            this.profitChart.update('none'); // Update without animation for performance
        } catch (error) {
            console.error('Error updating profit chart:', error);
        }
    }

    async updateTradingSummary() {
        try {
            // Update price range
            const pricesResponse = await fetch('/api/prices');
            const prices = await pricesResponse.json();

            const priceValues = Object.values(prices).map(p => p['ETH/USD'] || 0).filter(p => p > 0);
            if (priceValues.length > 0) {
                const minPrice = Math.min(...priceValues);
                const maxPrice = Math.max(...priceValues);
                $('#priceRange').text(`$${minPrice.toFixed(0)} - $${maxPrice.toFixed(0)}`);
            }

            // Update best opportunity
            const opportunitiesResponse = await fetch('/api/opportunities');
            const opportunities = await opportunitiesResponse.json();

            if (opportunities.length > 0) {
                const bestProfit = Math.max(...opportunities.map(o => o.profit_percentage));
                $('#bestOpportunity').text(`+${bestProfit.toFixed(2)}%`);
            } else {
                $('#bestOpportunity').text('0.00%');
            }

            // Update active exchanges
            const activeCount = Object.keys(prices).length;
            $('#activeExchanges').text(`${activeCount}/4`);

        } catch (error) {
            console.error('Error updating trading summary:', error);
        }
    }

    async updateRecentTrades() {
            try {
                const response = await fetch('/api/recent_trades');
                const exchangeTrades = await response.json();

                const container = $('#recentTradesContainer');
                container.empty();

                if (exchangeTrades.error) {
                    container.html('<div class="no-data">Error loading recent trades</div>');
                    return;
                }

                let hasData = false;
                Object.entries(exchangeTrades).forEach(([exchange, trades]) => {
                    if (trades && trades.length > 0) {
                        hasData = true;
                        trades.slice(0, 5).forEach(trade => {
                            const tradeHtml = `
                                <div class="trade-item">
                                    <div class="trade-info">
                                        <span class="trade-pair">${exchange.toUpperCase()}</span>
                                        <span class="trade-amount">${parseFloat(trade.amount).toFixed(4)} ETH</span>
                                    </div>
                                    <div class="trade-price">
                                        $${parseFloat(trade.price).toFixed(2)}
                                    </div>
                                    <div class="trade-side ${trade.side}">
                                        ${trade.side.toUpperCase()}
                                    </div>
                                </div>
                            `;
                            container.append(tradeHtml);
                        });
                    }
                });

                if (!hasData) {
                    container.html('<div class="no-data">No recent trades available</div>');
                }
            } catch (error) {
                console.error('Error updating recent trades:', error);
                $('#recentTradesContainer').html('<div class="no-data">Error loading trades</div>');
            }
        }

    showNotification(message, type = 'info') {
        // Simple notification system
        const notification = $(`
            <div class="notification ${type}">
                ${message}
            </div>
        `);

        $('body').append(notification);

        setTimeout(() => {
            notification.fadeOut(() => notification.remove());
        }, 3000);
    }
}

// Initialize dashboard when DOM is ready
$(document).ready(() => {
    new Dashboard();
});

// Add notification styles
const notificationStyles = `
    .notification {
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 8px;
        font-weight: 600;
        z-index: 1000;
        animation: slideIn 0.3s ease;
    }

    .notification.success {
        background: #00ff88;
        color: #000;
    }

    .notification.error {
        background: #ff4757;
        color: #fff;
    }

    .notification.info {
        background: #00d4ff;
        color: #000;
    }

    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    .no-opportunities,
    .no-trades {
        text-align: center;
        color: #888;
        padding: 20px;
        font-style: italic;
    }
`;

$('<style>').text(notificationStyles).appendTo('head');

function updateDashboard() {
        Promise.all([
            fetch('/api/bot_status').then(r => r.json()).catch(() => ({status: 'error'})),
            fetch('/api/balances').then(r => r.json()).catch(() => ({})),
            fetch('/api/prices').then(r => r.json()).catch(() => ({})),
            fetch('/api/opportunities').then(r => r.json()).catch(() => []),
            fetch('/api/trade_history').then(r => r.json()).catch(() => [])
        ]).then(([status, balances, prices, opportunities, trades]) => {
            updateBotStatus(status);
            updateBalances(balances);
            updatePrices(prices);
            updateOpportunities(opportunities);
            updateTradeHistory(trades);
            updateTradingSummary(prices, opportunities);
        }).catch(error => {
            console.error('Error updating dashboard:', error);
            showNotification('Failed to update dashboard data', 'error');
        });
    }

function updateTradeHistory(trades) {
        const container = document.getElementById('tradeHistory');
        if (!container) return;

        if (!trades || trades.length === 0) {
            container.innerHTML = '<div class="no-data">No trades executed yet</div>';
            return;
        }

        container.innerHTML = trades.map(trade => `
            <div class="trade-item">
                <div class="trade-info">
                    <span class="trade-pair">${trade.buy_exchange} → ${trade.sell_exchange}</span>
                    <span class="trade-time">${new Date(trade.timestamp).toLocaleTimeString()}</span>
                </div>
                <div class="trade-profit ${trade.profit >= 0 ? 'positive' : 'negative'}">
                    $${trade.profit.toFixed(2)} (${trade.profit_percentage.toFixed(2)}%)
                </div>
            </div>
        `).join('');
    }

    function updateTradingSummary(prices, opportunities) {
        // Update price range
        const priceValues = Object.values(prices).map(p => p['ETH/USD']).filter(p => p > 0);
        if (priceValues.length > 0) {
            const minPrice = Math.min(...priceValues);
            const maxPrice = Math.max(...priceValues);
            const priceRangeEl = document.getElementById('priceRange');
            if (priceRangeEl) {
                priceRangeEl.textContent = `$${minPrice.toFixed(0)} - $${maxPrice.toFixed(0)}`;
            }
        }

        // Update best opportunity
        if (opportunities && opportunities.length > 0) {
            const bestOpp = Math.max(...opportunities.map(o => o.profit_percentage));
            const bestOpportunityEl = document.getElementById('bestOpportunity');
            if (bestOpportunityEl) {
                bestOpportunityEl.textContent = `+${bestOpp.toFixed(2)}%`;
            }
        }

        // Update active exchanges count
        const activeCount = Object.keys(prices).filter(exchange => prices[exchange]['ETH/USD'] > 0).length;
        const totalCount = Object.keys(prices).length;
        const activeExchangesEl = document.getElementById('activeExchanges');
        if (activeExchangesEl) {
            activeExchangesEl.textContent = `${activeCount}/${totalCount}`;
        }
    }