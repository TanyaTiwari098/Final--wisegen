
import ccxt
import logging
import os
from datetime import datetime

logger = logging.getLogger(__name__)

class ExchangeManager:
    def __init__(self, config):
        self.config = config
        self.exchanges = {}
        self.initialize_exchanges()
    
    def initialize_exchanges(self):
        """Initialize exchange connections"""
        exchange_configs = {
            'binance': {
                'class': ccxt.binance,
                'sandbox': False,  # Use real trading environment
                'apiKey': os.environ.get('BINANCE_API_KEY'),
                'secret': os.environ.get('BINANCE_SECRET_KEY'),
                'enableRateLimit': True,
                'options': {'defaultType': 'spot'}
            },
            'kraken': {
                'class': ccxt.kraken,
                'sandbox': False,
                'apiKey': os.environ.get('KRAKEN_API_KEY'),
                'secret': os.environ.get('KRAKEN_SECRET_KEY'),
                'enableRateLimit': True
            },
            'bitget': {
                'class': ccxt.bitget,
                'sandbox': False,
                'apiKey': os.environ.get('BITGET_API_KEY'),
                'secret': os.environ.get('BITGET_SECRET_KEY'),
                'password': os.environ.get('BITGET_PASSPHRASE'),
                'enableRateLimit': True
            },
            'coinbase': {
                'class': ccxt.coinbase,
                'sandbox': False,
                'apiKey': os.environ.get('COINBASE_API_KEY'),
                'secret': os.environ.get('COINBASE_SECRET_KEY'),
                'enableRateLimit': True
            }
        }
        
        for exchange_name, exchange_config in exchange_configs.items():
            if self.config['exchanges'].get(exchange_name, {}).get('enabled', False):
                try:
                    exchange_class = exchange_config['class']
                    del exchange_config['class']
                    
                    exchange = exchange_class(exchange_config)
                    exchange.load_markets()
                    self.exchanges[exchange_name] = exchange
                    logger.info(f"Initialized {exchange_name} exchange")
                    
                except Exception as e:
                    logger.error(f"Failed to initialize {exchange_name}: {str(e)}")
    
    def get_all_prices(self):
        """Get current prices from all exchanges"""
        prices = {}
        
        # Get enabled exchanges from config
        enabled_exchanges = []
        if hasattr(self.config, 'get') and 'exchanges' in self.config:
            for exchange_name, config in self.config['exchanges'].items():
                if config.get('enabled', False):
                    enabled_exchanges.append(exchange_name)
        else:
            enabled_exchanges = ['binance', 'kraken', 'bitget']  # Default enabled
        
        for exchange_name in enabled_exchanges:
            try:
                if exchange_name in self.exchanges:
                    # Fetch real price from exchange
                    exchange = self.exchanges[exchange_name]
                    
                    # Different exchanges may have different symbols
                    symbol = 'ETH/USD'
                    if exchange_name == 'kraken':
                        symbol = 'ETH/USD'  # Kraken supports ETH/USD
                    elif exchange_name == 'binance':
                        symbol = 'ETH/USDT'  # Binance uses USDT
                    elif exchange_name == 'bitget':
                        symbol = 'ETH/USDT'  # Bitget uses USDT
                    
                    ticker = exchange.fetch_ticker(symbol)
                    logger.info(f"Fetched price from {exchange_name}: {ticker['last']}")
                    
                    prices[exchange_name] = {
                        'ETH/USD': ticker['last'],
                        'bid': ticker['bid'],
                        'ask': ticker['ask'],
                        'timestamp': datetime.now().isoformat()
                    }
                else:
                    logger.warning(f"Exchange {exchange_name} not initialized")
                    prices[exchange_name] = {
                        'ETH/USD': 0.0,
                        'bid': 0.0,
                        'ask': 0.0,
                        'timestamp': datetime.now().isoformat(),
                        'error': 'Exchange not initialized'
                    }
                    
            except Exception as e:
                logger.error(f"Error fetching price from {exchange_name}: {str(e)}")
                prices[exchange_name] = {
                    'ETH/USD': 0.0,
                    'bid': 0.0,
                    'ask': 0.0,
                    'timestamp': datetime.now().isoformat(),
                    'error': str(e)
                }
        
        return prices
    
    def get_balances(self):
        """Get balances from all exchanges"""
        balances = {}
        
        # Get enabled exchanges from config
        enabled_exchanges = []
        if hasattr(self.config, 'get') and 'exchanges' in self.config:
            for exchange_name, config in self.config['exchanges'].items():
                if config.get('enabled', False):
                    enabled_exchanges.append(exchange_name)
        else:
            enabled_exchanges = ['binance', 'kraken', 'bitget']  # Default enabled
        
        for exchange_name in enabled_exchanges:
            try:
                if exchange_name in self.exchanges:
                    # Fetch real balance from exchange
                    exchange = self.exchanges[exchange_name]
                    balance = exchange.fetch_balance()
                    logger.info(f"Fetched balance from {exchange_name}: {balance}")
                    
                    # Handle different exchange response formats
                    usd_balance = 0
                    eth_balance = 0
                    
                    if exchange_name == 'kraken':
                        # Kraken uses different currency codes
                        usd_balance = balance.get('ZUSD', {}).get('free', 0) or balance.get('USD', {}).get('free', 0)
                        eth_balance = balance.get('XETH', {}).get('free', 0) or balance.get('ETH', {}).get('free', 0)
                        usd_total = balance.get('ZUSD', {}).get('total', 0) or balance.get('USD', {}).get('total', 0)
                        eth_total = balance.get('XETH', {}).get('total', 0) or balance.get('ETH', {}).get('total', 0)
                    elif exchange_name == 'bitget':
                        # Bitget format
                        usd_balance = balance.get('USDT', {}).get('free', 0) or balance.get('USD', {}).get('free', 0)
                        eth_balance = balance.get('ETH', {}).get('free', 0)
                        usd_total = balance.get('USDT', {}).get('total', 0) or balance.get('USD', {}).get('total', 0)
                        eth_total = balance.get('ETH', {}).get('total', 0)
                    else:
                        # Binance and others
                        usd_balance = balance.get('USDT', {}).get('free', 0) or balance.get('USD', {}).get('free', 0)
                        eth_balance = balance.get('ETH', {}).get('free', 0)
                        usd_total = balance.get('USDT', {}).get('total', 0) or balance.get('USD', {}).get('total', 0)
                        eth_total = balance.get('ETH', {}).get('total', 0)
                    
                    balances[exchange_name] = {
                        'USD': float(usd_balance) if usd_balance else 0.0,
                        'ETH': float(eth_balance) if eth_balance else 0.0,
                        'total_usd': float(usd_total) if usd_total else 0.0,
                        'total_eth': float(eth_total) if eth_total else 0.0
                    }
                    
                else:
                    logger.warning(f"Exchange {exchange_name} not initialized")
                    balances[exchange_name] = {
                        'USD': 0.0,
                        'ETH': 0.0,
                        'total_usd': 0.0,
                        'total_eth': 0.0
                    }
                    
            except Exception as e:
                logger.error(f"Error fetching balance from {exchange_name}: {str(e)}")
                balances[exchange_name] = {
                    'USD': 0.0,
                    'ETH': 0.0,
                    'total_usd': 0.0,
                    'total_eth': 0.0,
                    'error': str(e)
                }
        
        return balances
    
    def buy_order(self, exchange_name, symbol, amount, price):
        """Place a buy order"""
        try:
            if exchange_name in self.exchanges:
                exchange = self.exchanges[exchange_name]
                order = exchange.create_limit_buy_order(symbol, amount, price)
                logger.info(f"Buy order placed on {exchange_name}: {order}")
                return True
            return False
        except Exception as e:
            logger.error(f"Error placing buy order on {exchange_name}: {str(e)}")
            return False
    
    def sell_order(self, exchange_name, symbol, amount, price):
        """Place a sell order"""
        try:
            if exchange_name in self.exchanges:
                exchange = self.exchanges[exchange_name]
                order = exchange.create_limit_sell_order(symbol, amount, price)
                logger.info(f"Sell order placed on {exchange_name}: {order}")
                return True
            return False
        except Exception as e:
            logger.error(f"Error placing sell order on {exchange_name}: {str(e)}")
            return False
    
    def get_order_book(self, exchange_name, symbol):
        """Get order book for a symbol"""
        try:
            if exchange_name in self.exchanges:
                exchange = self.exchanges[exchange_name]
                return exchange.fetch_order_book(symbol)
            return None
        except Exception as e:
            logger.error(f"Error fetching order book from {exchange_name}: {str(e)}")
            return None
