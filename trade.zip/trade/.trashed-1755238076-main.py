
from flask import Flask, render_template, jsonify, request
import threading
import time
import json
import logging
from datetime import datetime, timedelta
from arbitrage_bot import ArbitrageBot
from exchange_manager import ExchangeManager
from risk_manager import RiskManager
import os

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'crypto-arbitrage-bot-secret')

# Global bot instance
bot = None
bot_thread = None
bot_running = False

@app.route('/')
def dashboard():
    return render_template('dashboard.html')

@app.route('/api/start_bot', methods=['POST'])
def start_bot():
    global bot, bot_thread, bot_running
    
    try:
        if not bot_running:
            config = request.json
            bot = ArbitrageBot(config)
            bot_thread = threading.Thread(target=bot.run)
            bot_thread.daemon = True
            bot_thread.start()
            bot_running = True
            return jsonify({'status': 'success', 'message': 'Bot started successfully'})
        else:
            return jsonify({'status': 'error', 'message': 'Bot is already running'})
    except Exception as e:
        logger.error(f"Error starting bot: {str(e)}")
        return jsonify({'status': 'error', 'message': str(e)})

@app.route('/api/stop_bot', methods=['POST'])
def stop_bot():
    global bot, bot_running
    
    try:
        if bot_running and bot:
            bot.stop()
            bot_running = False
            return jsonify({'status': 'success', 'message': 'Bot stopped successfully'})
        else:
            return jsonify({'status': 'error', 'message': 'Bot is not running'})
    except Exception as e:
        logger.error(f"Error stopping bot: {str(e)}")
        return jsonify({'status': 'error', 'message': str(e)})

@app.route('/api/bot_status')
def bot_status():
    global bot, bot_running
    
    if bot_running and bot:
        return jsonify({
            'status': 'running',
            'uptime': bot.get_uptime(),
            'total_trades': bot.get_total_trades(),
            'total_profit': bot.get_total_profit(),
            'last_update': datetime.now().isoformat()
        })
    else:
        return jsonify({'status': 'stopped'})

@app.route('/api/balances')
def get_balances():
    global bot
    
    if bot:
        return jsonify(bot.get_balances())
    else:
        return jsonify({'error': 'Bot not initialized'})

@app.route('/api/prices')
def get_prices():
    global bot
    
    if bot:
        return jsonify(bot.get_current_prices())
    else:
        return jsonify({'error': 'Bot not initialized'})

@app.route('/api/opportunities')
def get_opportunities():
    global bot
    
    if bot:
        return jsonify(bot.get_arbitrage_opportunities())
    else:
        return jsonify({'error': 'Bot not initialized'})

@app.route('/api/trade_history')
def get_trade_history():
    global bot
    
    if bot:
        return jsonify(bot.get_trade_history())
    else:
        return jsonify({'error': 'Bot not initialized'})

@app.route('/api/profit_history')
def get_profit_history():
    global bot
    
    if bot:
        return jsonify(bot.get_profit_history())
    else:
        return jsonify({'error': 'Bot not initialized'})

@app.route('/api/recent_trades')
def get_recent_trades():
    global bot
    
    if bot:
        return jsonify(bot.get_recent_trades())
    else:
        return jsonify({'error': 'Bot not initialized'})

@app.route('/api/config', methods=['GET', 'POST'])
def bot_config():
    global bot
    
    if request.method == 'POST':
        config = request.json
        # Save config to file
        with open('bot_config.json', 'w') as f:
            json.dump(config, f, indent=2)
        return jsonify({'status': 'success', 'message': 'Configuration saved'})
    else:
        # Load config from file
        try:
            with open('bot_config.json', 'r') as f:
                config = json.load(f)
            return jsonify(config)
        except FileNotFoundError:
            # Return default config
            default_config = {
                'trading_pair': 'ETH/USD',
                'min_profit_percentage': 0.5,
                'max_trade_amount': 100,
                'risk_percentage': 2.0,
                'exchanges': {
                    'binance': {'enabled': True, 'weight': 1.0},
                    'kraken': {'enabled': True, 'weight': 1.0},
                    'bitget': {'enabled': True, 'weight': 1.0},
                    'coinbase': {'enabled': False, 'weight': 1.0}
                }
            }
            return jsonify(default_config)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
