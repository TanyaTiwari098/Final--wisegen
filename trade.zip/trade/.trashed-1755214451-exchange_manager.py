
import ccxt
import logging
import os
from datetime import datetime

logger = logging.getLogger(__name__)

class ExchangeManager:
    def __init__(self, config):
        self.config = config
        self.exchanges = {}
        self.initialize_exchanges()
    
    def initialize_exchanges(self):
        """Initialize exchange connections"""
        exchange_configs = {
            'binance': {
                'class': ccxt.binance,
                'sandbox': True,  # Use sandbox for testing
                'apiKey': os.environ.get('BINANCE_API_KEY'),
                'secret': os.environ.get('BINANCE_SECRET_KEY'),
                'enableRateLimit': True,
                'options': {'defaultType': 'spot'}
            },
            'kraken': {
                'class': ccxt.kraken,
                'sandbox': True,
                'apiKey': os.environ.get('KRAKEN_API_KEY'),
                'secret': os.environ.get('KRAKEN_SECRET_KEY'),
                'enableRateLimit': True
            },
            'bitget': {
                'class': ccxt.bitget,
                'sandbox': True,
                'apiKey': os.environ.get('BITGET_API_KEY'),
                'secret': os.environ.get('BITGET_SECRET_KEY'),
                'password': os.environ.get('BITGET_PASSPHRASE'),
                'enableRateLimit': True
            },
            'coinbase': {
                'class': ccxt.coinbase,
                'sandbox': True,
                'apiKey': os.environ.get('COINBASE_API_KEY'),
                'secret': os.environ.get('COINBASE_SECRET_KEY'),
                'enableRateLimit': True
            }
        }
        
        for exchange_name, exchange_config in exchange_configs.items():
            if self.config['exchanges'].get(exchange_name, {}).get('enabled', False):
                try:
                    exchange_class = exchange_config['class']
                    del exchange_config['class']
                    
                    exchange = exchange_class(exchange_config)
                    exchange.load_markets()
                    self.exchanges[exchange_name] = exchange
                    logger.info(f"Initialized {exchange_name} exchange")
                    
                except Exception as e:
                    logger.error(f"Failed to initialize {exchange_name}: {str(e)}")
    
    def get_all_prices(self):
        """Get current prices from all exchanges"""
        prices = {}
        
        for exchange_name, exchange in self.exchanges.items():
            try:
                ticker = exchange.fetch_ticker('ETH/USD')
                prices[exchange_name] = {
                    'ETH/USD': ticker['last'],
                    'bid': ticker['bid'],
                    'ask': ticker['ask'],
                    'timestamp': datetime.now().isoformat()
                }
            except Exception as e:
                logger.error(f"Error fetching price from {exchange_name}: {str(e)}")
                prices[exchange_name] = {'ETH/USD': 0}
        
        return prices
    
    def get_balances(self):
        """Get balances from all exchanges"""
        balances = {}
        
        for exchange_name, exchange in self.exchanges.items():
            try:
                balance = exchange.fetch_balance()
                balances[exchange_name] = {
                    'USD': balance.get('USD', {}).get('free', 0),
                    'ETH': balance.get('ETH', {}).get('free', 0),
                    'total_usd': balance.get('USD', {}).get('total', 0),
                    'total_eth': balance.get('ETH', {}).get('total', 0)
                }
            except Exception as e:
                logger.error(f"Error fetching balance from {exchange_name}: {str(e)}")
                # Mock balances for demo
                balances[exchange_name] = {
                    'USD': 1000.0,
                    'ETH': 0.5,
                    'total_usd': 1200.0,
                    'total_eth': 0.6
                }
        
        return balances
    
    def buy_order(self, exchange_name, symbol, amount, price):
        """Place a buy order"""
        try:
            if exchange_name in self.exchanges:
                exchange = self.exchanges[exchange_name]
                order = exchange.create_limit_buy_order(symbol, amount, price)
                logger.info(f"Buy order placed on {exchange_name}: {order}")
                return True
            return False
        except Exception as e:
            logger.error(f"Error placing buy order on {exchange_name}: {str(e)}")
            return False
    
    def sell_order(self, exchange_name, symbol, amount, price):
        """Place a sell order"""
        try:
            if exchange_name in self.exchanges:
                exchange = self.exchanges[exchange_name]
                order = exchange.create_limit_sell_order(symbol, amount, price)
                logger.info(f"Sell order placed on {exchange_name}: {order}")
                return True
            return False
        except Exception as e:
            logger.error(f"Error placing sell order on {exchange_name}: {str(e)}")
            return False
    
    def get_order_book(self, exchange_name, symbol):
        """Get order book for a symbol"""
        try:
            if exchange_name in self.exchanges:
                exchange = self.exchanges[exchange_name]
                return exchange.fetch_order_book(symbol)
            return None
        except Exception as e:
            logger.error(f"Error fetching order book from {exchange_name}: {str(e)}")
            return None
