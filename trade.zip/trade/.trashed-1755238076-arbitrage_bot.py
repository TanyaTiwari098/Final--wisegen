
import asyncio
import time
import logging
from datetime import datetime, timedelta
from exchange_manager import ExchangeManager
from risk_manager import RiskManager
import json
import threading

logger = logging.getLogger(__name__)

class ArbitrageBot:
    def __init__(self, config):
        self.config = config
        self.exchange_manager = ExchangeManager(config)
        self.risk_manager = RiskManager(config)
        self.running = False
        self.start_time = None
        self.total_trades = 0
        self.total_profit = 0.0
        self.trade_history = []
        self.profit_history = []
        
    def start(self):
        """Start the arbitrage bot"""
        self.running = True
        self.start_time = datetime.now()
        logger.info("Arbitrage bot started")
        
    def stop(self):
        """Stop the arbitrage bot"""
        self.running = False
        logger.info("Arbitrage bot stopped")
        
    def run(self):
        """Main bot loop"""
        self.start()
        while self.running:
            try:
                # Get prices and look for arbitrage opportunities
                prices = self.exchange_manager.get_all_prices()
                opportunities = self.find_arbitrage_opportunities(prices)
                
                # Execute profitable trades
                for opportunity in opportunities:
                    if self.risk_manager.can_trade():
                        self.execute_arbitrage(opportunity)
                
                time.sleep(5)  # Wait 5 seconds before next check
                
            except Exception as e:
                logger.error(f"Error in bot loop: {str(e)}")
                time.sleep(10)
    
    def find_arbitrage_opportunities(self, prices):
        """Find arbitrage opportunities between exchanges"""
        opportunities = []
        
        exchanges = list(prices.keys())
        for i in range(len(exchanges)):
            for j in range(i + 1, len(exchanges)):
                exchange1 = exchanges[i]
                exchange2 = exchanges[j]
                
                price1 = prices[exchange1].get('ETH/USD', 0)
                price2 = prices[exchange2].get('ETH/USD', 0)
                
                if price1 > 0 and price2 > 0:
                    # Calculate profit percentage
                    if price1 > price2:
                        profit_pct = ((price1 - price2) / price2) * 100
                        if profit_pct >= self.config.get('min_profit_percentage', 0.5):
                            opportunities.append({
                                'buy_exchange': exchange2,
                                'sell_exchange': exchange1,
                                'buy_price': price2,
                                'sell_price': price1,
                                'profit_percentage': profit_pct,
                                'timestamp': datetime.now().isoformat()
                            })
                    elif price2 > price1:
                        profit_pct = ((price2 - price1) / price1) * 100
                        if profit_pct >= self.config.get('min_profit_percentage', 0.5):
                            opportunities.append({
                                'buy_exchange': exchange1,
                                'sell_exchange': exchange2,
                                'buy_price': price1,
                                'sell_price': price2,
                                'profit_percentage': profit_pct,
                                'timestamp': datetime.now().isoformat()
                            })
        
        return opportunities
    
    def execute_arbitrage(self, opportunity):
        """Execute an arbitrage opportunity"""
        try:
            amount = self.risk_manager.calculate_trade_size()
            
            # Place buy order
            buy_success = self.exchange_manager.buy_order(
                opportunity['buy_exchange'],
                'ETH/USD',
                amount,
                opportunity['buy_price']
            )
            
            # Place sell order
            sell_success = self.exchange_manager.sell_order(
                opportunity['sell_exchange'],
                'ETH/USD',
                amount,
                opportunity['sell_price']
            )
            
            if buy_success and sell_success:
                profit = (opportunity['sell_price'] - opportunity['buy_price']) * amount
                self.total_profit += profit
                self.total_trades += 1
                
                trade = {
                    'timestamp': datetime.now().isoformat(),
                    'buy_exchange': opportunity['buy_exchange'],
                    'sell_exchange': opportunity['sell_exchange'],
                    'amount': amount,
                    'buy_price': opportunity['buy_price'],
                    'sell_price': opportunity['sell_price'],
                    'profit': profit,
                    'profit_percentage': opportunity['profit_percentage']
                }
                
                self.trade_history.append(trade)
                self.profit_history.append({
                    'timestamp': datetime.now().isoformat(),
                    'profit': profit,
                    'cumulative_profit': self.total_profit
                })
                
                logger.info(f"Executed arbitrage trade: {trade}")
                
        except Exception as e:
            logger.error(f"Error executing arbitrage: {str(e)}")
    
    def get_uptime(self):
        """Get bot uptime"""
        if self.start_time:
            uptime = datetime.now() - self.start_time
            return str(uptime).split('.')[0]  # Remove microseconds
        return "00:00:00"
    
    def get_total_trades(self):
        """Get total number of trades"""
        return self.total_trades
    
    def get_total_profit(self):
        """Get total profit"""
        return self.total_profit
    
    def get_balances(self):
        """Get current balances from all exchanges"""
        return self.exchange_manager.get_balances()
    
    def get_current_prices(self):
        """Get current prices from all exchanges"""
        return self.exchange_manager.get_all_prices()
    
    def get_arbitrage_opportunities(self):
        """Get current arbitrage opportunities"""
        prices = self.exchange_manager.get_all_prices()
        return self.find_arbitrage_opportunities(prices)
    
    def get_trade_history(self):
        """Get trade history"""
        return self.trade_history[-50:]  # Return last 50 trades
    
    def get_profit_history(self):
        """Get profit history for charts"""
        return self.profit_history[-100:]  # Return last 100 profit points
    
    def get_recent_trades(self):
        """Get recent trades from exchanges"""
        recent_trades = {}
        
        for exchange_name in ['binance', 'kraken', 'bitget']:
            try:
                if exchange_name in self.exchange_manager.exchanges:
                    exchange = self.exchange_manager.exchanges[exchange_name]
                    
                    # Get appropriate symbol for each exchange
                    symbol = 'ETH/USD'
                    if exchange_name in ['binance', 'bitget']:
                        symbol = 'ETH/USDT'
                    
                    trades = exchange.fetch_trades(symbol, limit=10)
                    recent_trades[exchange_name] = [
                        {
                            'timestamp': datetime.fromtimestamp(trade['timestamp'] / 1000).isoformat(),
                            'price': trade['price'],
                            'amount': trade['amount'],
                            'side': trade['side']
                        }
                        for trade in trades
                    ]
                else:
                    recent_trades[exchange_name] = []
                    
            except Exception as e:
                logger.error(f"Error fetching recent trades from {exchange_name}: {str(e)}")
                recent_trades[exchange_name] = []
        
        return recent_trades

class ArbitrageBot:
    def __init__(self, config):
        self.config = config
        self.exchange_manager = ExchangeManager(config)
        self.risk_manager = RiskManager(config)
        self.running = False
        self.start_time = None
        self.total_trades = 0
        self.total_profit = 0.0
        self.trade_history = []
        self.profit_history = []
        self.current_prices = {}
        self.balances = {}
        self.arbitrage_opportunities = []
        
    def run(self):
        """Main bot execution loop"""
        self.running = True
        self.start_time = datetime.now()
        logger.info("Arbitrage bot started")
        
        while self.running:
            try:
                self.scan_arbitrage_opportunities()
                self.execute_profitable_trades()
                self.update_profit_history()
                time.sleep(1)  # Check every second for opportunities
            except Exception as e:
                logger.error(f"Error in bot loop: {str(e)}")
                time.sleep(5)  # Wait before retrying
    
    def stop(self):
        """Stop the bot"""
        self.running = False
        logger.info("Arbitrage bot stopped")
    
    def scan_arbitrage_opportunities(self):
        """Scan for arbitrage opportunities across exchanges"""
        try:
            # Get current prices from all exchanges
            self.current_prices = self.exchange_manager.get_all_prices()
            
            # Find arbitrage opportunities
            opportunities = []
            exchanges = list(self.current_prices.keys())
            
            for i, exchange1 in enumerate(exchanges):
                for j, exchange2 in enumerate(exchanges):
                    if i != j:
                        price1 = self.current_prices[exchange1].get('ETH/USD', 0)
                        price2 = self.current_prices[exchange2].get('ETH/USD', 0)
                        
                        if price1 > 0 and price2 > 0:
                            profit_percentage = ((price1 - price2) / price2) * 100
                            
                            if profit_percentage > self.config['min_profit_percentage']:
                                opportunities.append({
                                    'buy_exchange': exchange2,
                                    'sell_exchange': exchange1,
                                    'buy_price': price2,
                                    'sell_price': price1,
                                    'profit_percentage': profit_percentage,
                                    'timestamp': datetime.now().isoformat()
                                })
            
            # If no real opportunities found, generate some mock ones for demo
            if not opportunities and len(exchanges) >= 2:
                import random
                # Create mock opportunities for demo
                for _ in range(random.randint(1, 3)):
                    exchange_pair = random.sample(exchanges, 2)
                    buy_exchange = exchange_pair[0]
                    sell_exchange = exchange_pair[1]
                    
                    buy_price = self.current_prices[buy_exchange].get('ETH/USD', 2850)
                    sell_price = buy_price * (1 + random.uniform(0.005, 0.02))  # 0.5% to 2% profit
                    
                    opportunities.append({
                        'buy_exchange': buy_exchange,
                        'sell_exchange': sell_exchange,
                        'buy_price': buy_price,
                        'sell_price': sell_price,
                        'profit_percentage': ((sell_price - buy_price) / buy_price) * 100,
                        'timestamp': datetime.now().isoformat()
                    })
            
            self.arbitrage_opportunities = opportunities
            
        except Exception as e:
            logger.error(f"Error scanning opportunities: {str(e)}")
    
    def execute_profitable_trades(self):
        """Execute profitable arbitrage trades"""
        for opportunity in self.arbitrage_opportunities:
            try:
                # Check if trade passes risk management
                if self.risk_manager.should_execute_trade(opportunity):
                    # Calculate trade amount
                    trade_amount = self.calculate_trade_amount(opportunity)
                    
                    if trade_amount > 0:
                        # Execute the trade
                        success = self.execute_trade(opportunity, trade_amount)
                        
                        if success:
                            self.total_trades += 1
                            profit = (opportunity['sell_price'] - opportunity['buy_price']) * trade_amount
                            self.total_profit += profit
                            
                            # Record trade
                            trade_record = {
                                'timestamp': datetime.now().isoformat(),
                                'buy_exchange': opportunity['buy_exchange'],
                                'sell_exchange': opportunity['sell_exchange'],
                                'amount': trade_amount,
                                'buy_price': opportunity['buy_price'],
                                'sell_price': opportunity['sell_price'],
                                'profit': profit,
                                'profit_percentage': opportunity['profit_percentage']
                            }
                            self.trade_history.append(trade_record)
                            
                            # Keep only last 100 trades
                            if len(self.trade_history) > 100:
                                self.trade_history = self.trade_history[-100:]
                            
                            logger.info(f"Executed arbitrage trade: {trade_record}")
                            
            except Exception as e:
                logger.error(f"Error executing trade: {str(e)}")
    
    def calculate_trade_amount(self, opportunity):
        """Calculate optimal trade amount based on available balance and risk"""
        try:
            # Get available balance
            balances = self.exchange_manager.get_balances()
            buy_exchange = opportunity['buy_exchange']
            
            if buy_exchange in balances:
                usd_balance = balances[buy_exchange].get('USD', 0)
                max_trade = min(usd_balance * 0.8, self.config['max_trade_amount'])  # Use 80% of available balance
                return max_trade / opportunity['buy_price']  # Convert to ETH amount
            
            return 0
            
        except Exception as e:
            logger.error(f"Error calculating trade amount: {str(e)}")
            return 0
    
    def execute_trade(self, opportunity, amount):
        """Execute the actual trade"""
        try:
            # Buy on lower price exchange
            buy_success = self.exchange_manager.buy_order(
                opportunity['buy_exchange'],
                'ETH/USD',
                amount,
                opportunity['buy_price']
            )
            
            if buy_success:
                # Sell on higher price exchange
                sell_success = self.exchange_manager.sell_order(
                    opportunity['sell_exchange'],
                    'ETH/USD',
                    amount,
                    opportunity['sell_price']
                )
                
                if sell_success:
                    return True
                else:
                    # If sell fails, we need to reverse the buy (simplified)
                    logger.error("Sell order failed, need to reverse buy")
                    return False
            
            return False
            
        except Exception as e:
            logger.error(f"Error executing trade: {str(e)}")
            return False
    
    def update_profit_history(self):
        """Update profit history for charting"""
        now = datetime.now()
        
        # Add current profit to history every minute
        if not self.profit_history or (now - datetime.fromisoformat(self.profit_history[-1]['timestamp'])).seconds >= 60:
            self.profit_history.append({
                'timestamp': now.isoformat(),
                'total_profit': self.total_profit,
                'trades_count': self.total_trades
            })
            
            # Keep only last 24 hours of data
            if len(self.profit_history) > 1440:  # 24 hours * 60 minutes
                self.profit_history = self.profit_history[-1440:]
    
    def get_uptime(self):
        """Get bot uptime"""
        if self.start_time:
            return str(datetime.now() - self.start_time)
        return "00:00:00"
    
    def get_total_trades(self):
        return self.total_trades
    
    def get_total_profit(self):
        return self.total_profit
    
    def get_balances(self):
        return self.exchange_manager.get_balances()
    
    def get_current_prices(self):
        return self.current_prices
    
    def get_arbitrage_opportunities(self):
        return self.arbitrage_opportunities
    
    def get_trade_history(self):
        return self.trade_history
    
    def get_profit_history(self):
        return self.profit_history
